//package ru.msu.cvc.lab2Info;

public class Controller {
	public static void main(String[] args) {

		// input
		String question0 = "Enter ";
		String question1 = "your name ";
		String question2 = "your age ";
		String question3 = "your hobby ";

		String answer1 = UserInput.input(question0 + question1);

		String answer2 = UserInput.input(question0 + question2);

		String answer3 = UserInput.input(question0 + question3);

		// output

		InfoOutput.output(question1, answer1);
		InfoOutput.output(question2, answer2);
		InfoOutput.output(question3, answer3);

		Line.lineHoriz();

	}
}
