//package ru.msu.cvc.lab2Info;

import java.util.Scanner;

// input from User
public class UserInput {
	static Scanner scanner = new Scanner(System.in);

	public static String input(String msg) {
		System.out.print(msg);
		return scanner.nextLine();

	}

}
