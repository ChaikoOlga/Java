//package ru.msu.cvc.lab2Info;

import java.util.stream.*;

public class Line {
	public static void lineHoriz() {
		String msg = "_";
		int n = 41;
		String msgRepeated = IntStream.range(0, n).mapToObj(i -> msg).collect(Collectors.joining(""));
		System.out.println(' ' + msgRepeated);

	}

	public static String lineVertic() {

		return "|  ";
	}

}
