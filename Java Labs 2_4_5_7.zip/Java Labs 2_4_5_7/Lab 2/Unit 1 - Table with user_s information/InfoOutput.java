//package ru.msu.cvc.lab2Info;

public class InfoOutput {
	public static void output(String quest, String answer) {
		Line.lineHoriz();

		String vertLine = Line.lineVertic();

		System.out.printf("%s" + "%16s" + "%s" + "%20s" + "%s" + "\n", vertLine, quest, vertLine, answer, vertLine);
	}

}