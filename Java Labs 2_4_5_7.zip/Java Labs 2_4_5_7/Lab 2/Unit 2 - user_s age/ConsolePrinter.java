//package ru.msu.cvc.lab2BirthDate;

// view
public class ConsolePrinter {
	public static void print(String msg) {
		System.out.println(msg);
	}

}
