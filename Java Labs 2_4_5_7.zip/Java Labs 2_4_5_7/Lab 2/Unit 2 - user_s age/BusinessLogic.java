//package ru.msu.cvc.lab2BirthDate;

public class BusinessLogic {
	public static final int NOW_YEAR = 2019;
	public static final int NOW_MONTH = 4;
	public static final int NOW_DAY = 2;
	public static final int YEAR_DAYS = 365;
	public static final int YEAR_MONTHS = 12;
	public static final int MONTH_DAYS = 30;

	public static int calcDaysLength(int day, int month, int year) {
		return (NOW_YEAR - year) * YEAR_DAYS + (NOW_MONTH - month) * MONTH_DAYS + (NOW_DAY - day);
	}

	public static int calcMonthsLength(int day, int month, int year) {
		return (NOW_YEAR - year) * YEAR_MONTHS + (NOW_MONTH - month);
	}

}
