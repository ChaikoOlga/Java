//package ru.msu.cvc.lab2BirthDate;

//controller
public class Test {
	public static void main(String[] args) {

		// input
		int birthYear = UserInput.input("Enter your birthday year: ");
		int birthMonth = UserInput.input("Enter your birthday month: ");
		int birthDate = UserInput.input("Enter your birthday day: ");

		// logic
		int days = BusinessLogic.calcDaysLength(birthDate, birthMonth, birthYear);

		int months = BusinessLogic.calcMonthsLength(birthDate, birthMonth, birthYear);

		String msg = "Your age is ";

		// output
		ConsolePrinter.print(msg + days + " days.\n");
		ConsolePrinter.print(msg + months + " months.");

	}

}
