//package ru.msu.cvc.lab4NumChange;

public class JoinMain {
	public static void main(String[] args) {
		int firstNumber = UserInput.print("Enter first number: ");
		int secondNumber = UserInput.print("Enter second number: ");

		int changedFirstNumber = BusinessLogic.changeNumber1(firstNumber, secondNumber);
		int changedSecondNumber = BusinessLogic.changeNumber2(firstNumber, secondNumber);

		ConsolePrinter.print("The changed first number is " + changedFirstNumber);
		ConsolePrinter.print("The changed second number is " + changedSecondNumber);
	}
}
