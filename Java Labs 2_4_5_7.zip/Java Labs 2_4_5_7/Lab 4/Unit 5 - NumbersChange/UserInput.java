//package ru.msu.cvc.lab4NumChange;

import java.util.Scanner;

public class UserInput {
	static Scanner scanner = new Scanner(System.in);

	public static int print(String msg) {
		System.out.print(msg);
		return scanner.nextInt();
	}

}
