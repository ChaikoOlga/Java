//package ru.msu.cvc.lab4NumChange;

public class BusinessLogic {

	public static int changeNumber1(int number1, int number2) {
		number1 = number1 + number2;
		number2 = number2 - number1;
		number2 = -number2;
		number1 = number1 - number2;
		return number1;

	}

	public static int changeNumber2(int number1, int number2) {
		number1 = number1 + number2;
		number2 = number2 - number1;
		number2 = -number2;
		return number2;
	}

}
