//package ru.msu.cvc.Dinosa�Weight;

import java.util.Scanner;

public class UserInput {
	static Scanner scanner = new Scanner(System.in);

	public static long input(String msg) {
		System.out.println(msg);
		return scanner.nextLong();
	}

}
