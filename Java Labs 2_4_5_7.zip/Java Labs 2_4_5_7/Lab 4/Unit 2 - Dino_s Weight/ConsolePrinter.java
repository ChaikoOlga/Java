//package ru.msu.cvc.Dinosa�Weight;

public class ConsolePrinter {
	public static void print(String msg) {
		System.out.println(msg);

	}

}
