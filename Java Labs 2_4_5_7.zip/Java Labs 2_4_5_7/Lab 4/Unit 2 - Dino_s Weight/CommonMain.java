//package ru.msu.cvc.Dinosa�Weight;

public class CommonMain {
	public static void main(String[] args) {
		
		long grammDinoWeight = UserInput.input("Enter the Dino's Weight in gramms: ");
		
		long kiloDinoWeight = BusinessLogic.converToKilo(grammDinoWeight);
		long centnerDinoWeight = BusinessLogic.converToCentner(grammDinoWeight);
		long tonDinoWeight = BusinessLogic.converToTon(grammDinoWeight);
		
		
		ConsolePrinter.print("The Dino's Weight in kilos is " + kiloDinoWeight);
		ConsolePrinter.print("The Dino's Weight in kilos is " + centnerDinoWeight);
		ConsolePrinter.print("The Dino's Weight in tons is " + tonDinoWeight);
		
		
	}

}
