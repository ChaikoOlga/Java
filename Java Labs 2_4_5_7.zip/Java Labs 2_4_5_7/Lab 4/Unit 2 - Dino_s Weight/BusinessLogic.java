//package ru.msu.cvc.Dinosa�Weight;

public class BusinessLogic {
	public static final long GRAMM_IN_KILO = 1000;
	public static final long GRAMM_IN_CENTNER = 100000;
	public static final long GRAMM_IN_TON = 1000000;

	public static long converToKilo(long gramm) {
		return gramm / GRAMM_IN_KILO;

	}

	public static long converToCentner(long gramm) {
		return gramm / GRAMM_IN_CENTNER;

	}

	public static long converToTon(long gramm) {
		return gramm / GRAMM_IN_TON;

	}

}
