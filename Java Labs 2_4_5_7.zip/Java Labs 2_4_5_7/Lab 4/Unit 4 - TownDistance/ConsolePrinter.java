//package ru.msu.cvc.lab04SmToKm;

public class ConsolePrinter {
	public static void printer(String msg) {
		System.out.println(msg);

	}

}
