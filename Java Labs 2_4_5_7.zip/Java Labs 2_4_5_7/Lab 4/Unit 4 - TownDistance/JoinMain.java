//package ru.msu.cvc.lab04SmToKm;

public class JoinMain {
	public static void main(String[] args) {

		long cm = UserInput.input("Enter the distance beetweet towns: ");

		long km = BusinessLogic.convertToKm(cm);
		long m = BusinessLogic.convertToM(cm);

		String msg = "The distance beetweet towns is ";
		ConsolePrinter.printer(msg + km + " km. ");
		ConsolePrinter.printer(msg + m + " m. ");
	}

}
