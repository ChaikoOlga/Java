//package ru.msu.cvc.lab04SmToKm;

public class BusinessLogic {
	public static final long CM_IN_M = 100;
	public static final long CM_IN_KM = 100000;

	public static long convertToKm(long cm) {
		return cm / CM_IN_KM;

	}

	public static long convertToM(long cm) {
		return cm / CM_IN_M;

	}

}
