//package ru.msu.cvc.Temp;

public class TemprechTransfer {
	public static void main(String[] args) {

		// input
		int far = UserInput.input("Enter Fahrenheit temperature: ");
		int cel = UserInput.input("Enter temperature in Celsius: ");

		// logic
		int transfToFar = BusinessLogic.calculateToFareng(cel);
		int transfToCel = BusinessLogic.calculateToCelc(far);

		// output
		String msg1 = " Fahrenheit degrees is ";
		String msg2 = " degrees in Celsius is ";

		PrinterConsole.print(far + msg1 + transfToCel + " in Celsius.");
		PrinterConsole.print(cel + msg2 + transfToFar + " in Fahrenheit.");
	}

}
