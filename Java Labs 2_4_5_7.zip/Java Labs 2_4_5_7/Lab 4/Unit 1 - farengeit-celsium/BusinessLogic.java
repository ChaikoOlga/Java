//package ru.msu.cvc.Temp;

public class BusinessLogic {

	public static final int CHANGE_TO_FARENGEIT = 9 / 5 + 32;
	public static final int CHANGE_TO_CELSIUS = 5 / 9 - 32;

	public static int calculateToFareng(int cel) {
		return cel * CHANGE_TO_FARENGEIT;

	}

	public static int calculateToCelc(int far) {
		return far * CHANGE_TO_CELSIUS;

	}
}
