//package ru.msu.cvc.Temp;

// view
public class PrinterConsole {
	public static void print(String msg) {
		System.out.println(msg);
	}

}