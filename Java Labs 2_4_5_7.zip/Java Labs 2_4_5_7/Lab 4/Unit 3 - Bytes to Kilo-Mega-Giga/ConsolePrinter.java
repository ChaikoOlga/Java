//package ru.msu.cvc.lab4byteConvert;

public class ConsolePrinter {
	public static void print(String msg) {
		System.out.println(msg);

	}

}
