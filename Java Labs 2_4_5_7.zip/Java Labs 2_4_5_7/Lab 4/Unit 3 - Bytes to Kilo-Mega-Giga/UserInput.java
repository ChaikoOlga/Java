//package ru.msu.cvc.lab4byteConvert;

import java.util.Scanner;

public class UserInput {
	static Scanner scanner = new Scanner(System.in);

	public static long input(String msg) {
		System.out.print(msg);
		return scanner.nextLong();
	}

}
