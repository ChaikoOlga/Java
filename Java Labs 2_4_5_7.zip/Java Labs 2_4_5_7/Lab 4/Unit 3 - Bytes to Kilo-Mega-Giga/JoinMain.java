//package ru.msu.cvc.lab4byteConvert;

public class JoinMain {
	public static void main(String[] args) {
		// input
		long bytes = UserInput.input("Enter the file's size in bytes: ");

		// business logic
		long kilobytes = BusinessLogic.convertToKilobyte(bytes);
		long megabytes = BusinessLogic.convertToMegabyte(bytes);
		long gigabytes = BusinessLogic.convertToGigabyte(bytes);

		// output
		String msg = "The size of your file is ";
		ConsolePrinter.print(msg + kilobytes + " kilobytes.");
		ConsolePrinter.print(msg + megabytes + " megabytes.");
		ConsolePrinter.print(msg + gigabytes + " gigabytes.");

	}

}
