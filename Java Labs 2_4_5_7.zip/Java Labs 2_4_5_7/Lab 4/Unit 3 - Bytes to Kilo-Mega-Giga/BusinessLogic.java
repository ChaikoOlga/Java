//package ru.msu.cvc.lab4byteConvert;

public class BusinessLogic {
	public static final long BYTE_IN_KILOBYTE = 1024;
	public static final long BYTE_IN_MEGABYTE = 1024 * 1024;
	public static final long BYTE_IN_GIGABYTE = 1024 * 1024 * 1024;

	public static long convertToKilobyte(long bytes) {
		return bytes / BYTE_IN_KILOBYTE;

	}

	public static long convertToMegabyte(long bytes) {
		return bytes / BYTE_IN_MEGABYTE;

	}

	public static long convertToGigabyte(long bytes) {
		return bytes / BYTE_IN_GIGABYTE;

	}

}
