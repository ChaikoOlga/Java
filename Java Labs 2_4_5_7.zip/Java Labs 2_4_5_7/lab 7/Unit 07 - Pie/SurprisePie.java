import java.util.Random;


public class SurprisePie {
	public static final String PIE_FILLING1 = "potato";
	public static final String PIE_FILLING2 = "cherry";
	public static final String PIE_FILLING3 = "poison";
	public static final String PIE_FILLING4 = "ring";
	public static final String PIE_FILLING5 = "advantages";


	static Random random = new Random();

	public static void main(String[] args) {
		int pie =random.nextInt(5);
		String surprise = PIE_FILLING1;

		switch(pie) {
			case 0: surprise = PIE_FILLING2; break;
			case 1: surprise = PIE_FILLING3; break;
			case 2: surprise = PIE_FILLING4; break;
			case 4: surprise = PIE_FILLING5; break;
		}

		System.out.print("The pie with " + surprise);
			
		}


	}


