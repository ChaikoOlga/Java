
public class DragonLogica {

	public static final int YOUNG_AGE = 200;
	public static final int YOUNG_HEARDS = 3;
	public static final int MIDDLE_AGE = 300;
	public static final int MIDDLE_HEARDS = 2;
	public static final int OLD_HEARDS = 1;
	public static final int EYE = 2;

	public static int costHeads(int year) {

		int heads = 0;
		if (year < YOUNG_AGE) {
			heads = year * YOUNG_HEARDS;
		} else if (year >= YOUNG_AGE && year < MIDDLE_AGE) {
			heads = YOUNG_AGE * YOUNG_HEARDS + (year - YOUNG_AGE) * MIDDLE_HEARDS;
		} else {
			heads = YOUNG_AGE * YOUNG_HEARDS + (year - YOUNG_AGE) * MIDDLE_HEARDS
					+ (year - YOUNG_HEARDS - MIDDLE_AGE) * OLD_HEARDS;
		}

		return heads;

	}

	public static int costEye(int heads) {
		return heads * EYE;
	}

}
