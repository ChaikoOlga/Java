import java.util.Random;

public class DragonHeadsEye {

	public static void main(String[] args) {

		Random random = new Random();

		int limit = UserInput.input("Enter the limit for Dragon's age (positive number): ");

		if (limit < 0) {
			System.out.print("Wrong value");
			return;
			
		} else {

			int year = random.nextInt(limit);

			int heads = DragonLogica.costHeads(year);

			int eyes = DragonLogica.costEye(heads);

			ConsoleOutput.output(
					"In the age of " + year + " years the Dragon has " + heads + " heads and " + eyes + " eyes. ");

		}
	}

}