//package lab7U16Arithmetic;

public class ConsolePrinter {
	
	public static void print(String msg) {
		
		System.out.print(msg);
	}

}
