//package lab7U16Arithmetic;

public class ArithmeticOperation {
	public static void main(String[] args) {
		String operator = UserInput.inputString("Enter the operator: ");
		double a = UserInput.inputDouble("Enter a: ");
		double b = UserInput.inputDouble("Enter b: ");
		
		double msg = BusinessLogic.findResult(operator, a, b);
		
		ConsolePrinter.print("The result is " + msg);
	}

}
