//package lab7U16Arithmetic;

import java.util.Scanner;

public class UserInput {
	private static Scanner scanner = new Scanner(System.in);

	public static double inputDouble(String msg) {
		System.out.print(msg);
		return scanner.nextDouble();

	}
	
	public static String inputString(String msg) {
		System.out.print(msg);
		return scanner.next();
	}

}
