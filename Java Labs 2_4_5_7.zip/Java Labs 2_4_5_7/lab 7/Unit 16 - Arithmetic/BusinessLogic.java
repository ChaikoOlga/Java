//package lab7U16Arithmetic;

public class BusinessLogic {
	public static double findResult(String operator, double a, double b) {
		double result = 0;

		switch (operator) {
		case "+":
			result = a + b;
			break;
		case "-":
			result = a - b;
			break;
		case "*":
			result = a * b;
			break;
		case "/":
			if (b != 0) {
				result = a / b;
			} else {
				System.out.println("Error: division by zero");
				
				
			}; break;
		case "%":
			if (b != 0) {
				result = a % b;
			} else {
				System.out.print("Error: division by zero");

			}; break;

		}
		
		return result;
	}

}
