//package lab7U11YearMounth;

import java.util.Scanner;;

public class UserInput {
	private static final Scanner scanner = new Scanner(System.in);

	public static int input(String msg) {
		System.out.print(msg);
		return scanner.nextInt();

	}

}
