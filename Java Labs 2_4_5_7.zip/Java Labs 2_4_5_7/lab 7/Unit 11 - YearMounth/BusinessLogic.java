//package lab7U11YearMounth;

public class BusinessLogic {
	public static String defineDays(int mounth) {
		String msg = "The number is out of range";

		switch (mounth) {
		case 1:
			msg = "31";
			break;
		case 2:
			msg = "28";
			break;
		case 3:
			msg = "31";
			break;
		case 4:
			msg = "30";
			break;
		case 5:
			msg = "31";
			break;
		case 6:
			msg = "30";
			break;
		case 7:
			msg = "31";
			break;
		case 8:
			msg = "31";
			break;
		case 9:
			msg = "30";
			break;
		case 10:
			msg = "31";
			break;
		case 11:
			msg = "30";
			break;
		case 12:
			msg = "31";
			break;
		}
		return msg;
	}

}
