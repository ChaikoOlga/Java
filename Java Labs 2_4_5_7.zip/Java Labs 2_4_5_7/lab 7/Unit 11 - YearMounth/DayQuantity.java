//package lab7U11YearMounth;

public class DayQuantity {
	public static void main(String[] args) {
		
		int month = UserInput.input("Enter the month's number beetween 1 and 12: ");
		
		String msg = BusinessLogic.defineDays(month);
		
		ConsolePrinter.print(msg);

	}

}
