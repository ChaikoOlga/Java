public class VovelArray {
	public static final String VOLVE = "Volve";
	public static final String CONSOLANT = "Consolant";
	
	public static void main(String[] args) {
		String letter = UserInput.input("Enter the letter: ");

		String [] array = {"a", "e", "y", "u", "i", "o"};

		String result = CONSOLANT;

		for (int i  =0; i < 6; i++) {
			if (letter == array[i]) {

				result = VOLVE;

			}

		}


		System.out.print(result + " letter");
			
		}


	}


