public class VovelSwitch {
	
	public static void main(String[] args) {
		String letter = UserInput.input("Enter the letter: ");
		String msg = "There is a consonant letter.";
		switch(letter) {
			case "a": 
			case "e":
			case "u":
			case "y":
			case "i":
			case "o": msg="There is a volve."; break;
		}

		System.out.print(msg);
			
		}


	}


