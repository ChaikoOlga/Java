public class VovelIfElse {
	
	public static void main(String[] args) {
		String letter = UserInput.input("Enter the letter: ");

		String msg = "There is a consonant letter.";

		if (letter == "a" || letter == "e" || letter == "y" || letter == "u" || letter =="i" || letter == "o" ) {
			msg = "There is a volve.";
		}

		System.out.print(msg);
			
		}


	}


