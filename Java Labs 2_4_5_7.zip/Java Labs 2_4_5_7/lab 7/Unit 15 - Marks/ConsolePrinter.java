//package lab7U15Marks;

public class ConsolePrinter {
	
	public static void print(String msg) {
		
		System.out.print(msg);
	}

}
