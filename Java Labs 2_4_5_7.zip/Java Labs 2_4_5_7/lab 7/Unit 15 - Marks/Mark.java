//package lab7U15Marks;

public class Mark {
	public static void main(String[] args) {
		int M = UserInput.input("Enter your mark: ");

		String msg = BusinessLogic.describeMark(M);

		ConsolePrinter.print(msg);
	}

}
