//package lab7U15Marks;

public class BusinessLogic {
	public static String describeMark(int M) {
		String msg = "The mark is out of the range";

		if (M > 0 && M < 3) {
			msg = "Very bad";
		} else if (M >= 3 && M < 5) {
			msg = "Poor";
		} else if (M >= 5 && M < 7) {
			msg = "So-so";
		} else if (M >= 7 && M < 9) {
			msg = "Good";
		} else if (M <= 10) {
			msg = "Excelent";
		}
		return msg;

	}

}
