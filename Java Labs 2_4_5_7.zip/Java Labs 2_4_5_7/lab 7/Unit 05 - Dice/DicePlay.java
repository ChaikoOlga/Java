public class DicePlay {

	public static void main(String[] args) {

		//int res = DiceLogic.rollTheDice();

		ConsoleOutput.output("Two dice roll give you " + DiceLogic.valueDice1 + ", " + DiceLogic.valueDice2 + 
				" and the result is " + DiceLogic.rollTheDice());
	}

}
