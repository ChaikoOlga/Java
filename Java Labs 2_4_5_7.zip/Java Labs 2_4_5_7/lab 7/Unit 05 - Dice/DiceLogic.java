import java.util.Random;

public class DiceLogic {
	static Random random = new Random();

	static int valueDice1 = random.nextInt(6) + 1;
	static int valueDice2 = random.nextInt(6) + 1;

	public static int rollTheDice() {

		return valueDice1 + valueDice2;

	}

}
