//package lab7U12YearTime;

public class YearTime {
	public static void main(String[] args) {
		int month = UserInput.input("Enter the month's number: ");

		String msg = BusinessLogic.defineTimeOfYear(month);

		ConsolePrinter.print(msg);
	}

}
