//package lab7U12YearTime;

public class ConsolePrinter {
	
	public static void print(String msg) {
		
		System.out.print(msg);
	}

}
