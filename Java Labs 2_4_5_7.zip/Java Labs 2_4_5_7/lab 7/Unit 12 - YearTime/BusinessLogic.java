//package lab7U12YearTime;

public class BusinessLogic {
	public static String defineTimeOfYear(int month) {
		String msg = "Out of range";

		switch (month) {
		case 12:
		case 1:
		case 2:
			msg = "Winter";
			break;
		case 3:
		case 4:
		case 5:
			msg = "Spring";
			break;
		case 6:
		case 7:
		case 8:
			msg = "Summer";
			break;
		case 9:
		case 10:
		case 11:
			msg = "Autumn";
			break;
		}
		return msg;
	}

}
