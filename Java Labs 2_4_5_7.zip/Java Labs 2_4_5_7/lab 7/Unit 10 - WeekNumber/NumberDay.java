//package lab7U10WeekNumber;

public class NumberDay {
	public static void main(String[] args) {
		
		int number = UserInput.input("Enter the number between 1 and 7: ");
		
		String msg = BusinessLogic.defineDay(number);
		
		ConsolePrinter.print(msg);
	}

}
