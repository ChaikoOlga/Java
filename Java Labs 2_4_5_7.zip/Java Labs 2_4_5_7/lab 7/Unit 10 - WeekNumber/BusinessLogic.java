//package lab7U10WeekNumber;

public class BusinessLogic {

	public static String defineDay(int number) {
		String msg = "The number is out of the range";

		switch (number) {
		case 1:
			msg = "Monday";
			break;
		case 2:
			msg = "Tuesday";
			break;
		case 3:
			msg = "Wednesday";
			break;
		case 4:
			msg = "Thursday";
			break;
		case 5:
			msg = "Friday";
			break;
		case 6:
			msg = "Saturday";
			break;
		case 7:
			msg = "Sunday";
			break;
		}

		return msg;
	}
}
