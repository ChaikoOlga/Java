
class MoodSensor {

	public static void main(String[] args) {
		
		String mood = MoodLogic.determineMood();
		ConsoleOutput.output("Your mood looks like  " + mood);
	}

}
