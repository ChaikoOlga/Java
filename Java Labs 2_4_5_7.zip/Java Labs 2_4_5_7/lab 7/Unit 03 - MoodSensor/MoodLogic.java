import java.util.Random;

public class MoodLogic {
	public static final String GOOD_MOOD = "(^____^)";
	public static final String BORING_MOOD = "(<_>)";
	public static final String ANGRY_MOOD = "(>_<)";
	public static final String STRICT_MOOD = "(*_*)";


	static Random random = new Random(); 

	public static String determineMood() {
		
		int mood = random.nextInt(4);
		
		String moodToday = GOOD_MOOD;

		switch(mood) {
			case 1: moodToday = BORING_MOOD; break;
			case 2: moodToday = ANGRY_MOOD; break;
			case 3: moodToday = STRICT_MOOD; break;
		}

		return moodToday;

	}

}
