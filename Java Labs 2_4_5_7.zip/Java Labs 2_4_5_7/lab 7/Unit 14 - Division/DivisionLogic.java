//package lab7U14Division;

public class DivisionLogic {
	public static String defineMultiplicity(int number) {
		String msg = "The number times";

		if (number % 2 == 0) {
			msg += " 2 ";
		}
		if (number % 3 == 0) {
			msg += " 3 ";
		}
		if (number % 5 == 0) {
			msg += " 5 ";
		}
		if (number % 7 == 0) {
			msg += " 7 ";
		}
		if (number % 11 == 0) {
			msg += " 11 ";
		}
		if (number % 13 == 0) {
			msg += " 13 ";
		}
		if (number % 19 == 0) {
			msg += " 19";
		}
		if (Math.abs(number % 2) > 0 && Math.abs(number % 3) > 0 && Math.abs(number % 5) > 0 && Math.abs(number % 7) > 0
				&& Math.abs(number % 11) > 0 && Math.abs(number % 13) > 0 && Math.abs(number % 19) > 0) {
			msg += "only itself";
		}

		return msg;
	}

}
