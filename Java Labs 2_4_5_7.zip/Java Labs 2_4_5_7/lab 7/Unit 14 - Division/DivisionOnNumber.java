//package lab7U14Division;

public class DivisionOnNumber {
	public static void main(String[] args) {
		int number = UserInput.input("Enter the number: ");

		String msg = DivisionLogic.defineMultiplicity(number);

		ConsolePrinter.print(msg);

	}

}
