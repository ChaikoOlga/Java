//package lab7U9NumberInLetters;

public class ConsolePrinter {
	
	public static void print(String msg) {
		
		System.out.print(msg);
	}

}
