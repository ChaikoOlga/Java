//package lab7U9NumberInLetters;

public class NumberInWord {
	public static void main(String[] args) {
		int userValue = UserInput.input("Enter your number: ");

		String result = LetterLogic.transtateNumber(userValue);

		ConsolePrinter.print(result);
	}

}
