
public class IncreasingSequence {
	
	public static void main(String[] args) {
		
		int userValue = UserInput.input("Enter four digit number: ");
		
		boolean result = BusinessLogic.findArithmetSequence(userValue);
		
		String msg = (result == true)?"This is an increasing sequence":"This is not an increasing sequence";
		
		ConsolePrinter.print(msg);
		
	}

}
