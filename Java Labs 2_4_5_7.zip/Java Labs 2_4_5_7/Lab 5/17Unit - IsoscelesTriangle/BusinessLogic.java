
public class BusinessLogic {
	public static boolean isTriangle(int side1, int side2, int side3) {

		boolean realTriangle = (side1 > 0 && side2 > 0 && side3 > 0) && (side1 + side2 > side3) && (side2 + side3 > side1)
				&& (side1 + side3 > side2);

		boolean equilateralTriangle = (side1 == side2) && (side1 == side3);

		return realTriangle && equilateralTriangle;

	}

}
