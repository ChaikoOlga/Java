//package lab5U18_RightTriangle;

public class TriangleLogic {
	public static boolean isRightEquilateralTriangle(double side1, double side2, double side3) {

		boolean realTriangle = (side1 > 0 && side2 > 0 && side3 > 0) && (side1 + side2 > side3)
				&& (side2 + side3 > side1) && (side1 + side3 > side2);

		boolean rightTriangle = (Math.pow(side1, 2) == Math.pow(side2, 2) + Math.pow(side3, 2))
				|| (Math.pow(side2, 2) == Math.pow(side1, 2) + Math.pow(side3, 2))
				|| (Math.pow(side3, 2) == Math.pow(side2, 2) + Math.pow(side1, 2));

		boolean equilateralTriangle = (side1 == side2) || (side2 == side3) || (side1 == side3);

		return realTriangle && rightTriangle && equilateralTriangle;

	}

}
