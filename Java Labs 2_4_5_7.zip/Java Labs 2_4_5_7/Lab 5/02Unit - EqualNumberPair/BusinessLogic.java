//package lab5U2_OneEqualPair;

public class BusinessLogic {

	public static boolean findEqualPair(double value1, double value2, double value3) {

		boolean answer1_2 = value1 == Math.abs(value2);
		boolean answer1_3 = value1 == Math.abs(value3);
		boolean answer2_3 = value2 == Math.abs(value3);

		return answer1_2 || answer1_3 || answer2_3;

	}

}
