//package lab5U2_OneEqualPair;

public class EqualNumberPair {

	public static void main(String[] args) {

		String msg = "Enter the number please: ";

		double value1 = UserInput.input(msg);
		double value2 = UserInput.input(msg);
		double value3 = UserInput.input(msg);

		boolean result = BusinessLogic.findEqualPair(value1, value2, value3);

		ConsoleOutput.output("The result is " + result);
	}

}
