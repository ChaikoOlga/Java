//package lab5U2_OneEqualPair;

public class ConsoleOutput {
	
	public static void output(String msg) {
		
		System.out.println(msg);
		
	}

}
