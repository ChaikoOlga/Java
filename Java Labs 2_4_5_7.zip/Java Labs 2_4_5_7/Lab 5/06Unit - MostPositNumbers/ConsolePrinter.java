public class ConsolePrinter {

	public static void output(String msg) {

		System.out.println(msg);

	}

}
