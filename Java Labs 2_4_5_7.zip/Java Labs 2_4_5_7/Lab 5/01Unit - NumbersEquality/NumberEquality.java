package lab5U1Equal3Numb;

public class NumberEquality {
	public static void main(String[] args) {

		String msg = "Enter number: ";
		double value1 = UserInput.input(msg);
		double value2 = UserInput.input(msg);
		double value3 = UserInput.input(msg);

		boolean result = BusinessLogic.compareNumbers(value1, value2, value3);

		ConsolePrinter
				.output("The equality between numbers " + value1 + ", " + value2 + ", " + value3 + " is " + result);
	}

}
