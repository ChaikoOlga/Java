package lab5U1Equal3Numb;

import java.util.Scanner;

public class UserInput {

	static Scanner scanner = new Scanner(System.in);

	public static double input(String msg) {

		System.out.println(msg);

		return scanner.nextDouble();

	}

}
