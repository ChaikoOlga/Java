package lab5U1Equal3Numb;

public class BusinessLogic {

	public static boolean compareNumbers(double value1, double value2, double value3) {

		boolean answer12 = value1 == value2;
		boolean answer13 = value1 == value3;
		boolean answer23 = value2 == value3;

		return answer12 && answer13 && answer23;

	}

}
