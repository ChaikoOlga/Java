package lab5U1Equal3Numb;

public class ConsolePrinter {
	
	public static void output(String msg) {
		
		System.out.print(msg);

	}

}
