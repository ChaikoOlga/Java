//package lab5U18_RightTriangle;

public class ConsolePrinter {
	
	public static void print(String msg) {
		
		System.out.print(msg);
	}

}
