//package lab5U18_RightTriangle;

public class RightTriangle {
	public static void main(String[] args) {

		String msg = "Enter the length of the side";

		double side1 = UserInput.input(msg + " 1:");
		double side2 = UserInput.input(msg + " 2:");
		double side3 = UserInput.input(msg + " 3:");

		boolean res = TriangleLogic.isRightTriangle(side1, side2, side3);

		ConsolePrinter.print("Result is " + res);

	}

}
