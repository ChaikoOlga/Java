import java.util.Scanner;

public class UserInput {
	static Scanner scanner = new Scanner(System.in);

	public static double input(String msg) {

		System.out.print(msg);
		return scanner.nextDouble();
	}

}
