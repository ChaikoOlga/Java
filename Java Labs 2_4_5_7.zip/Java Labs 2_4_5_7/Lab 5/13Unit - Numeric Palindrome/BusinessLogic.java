
public class BusinessLogic {
	public static final int THOUSAND_DIVISION = 1000;
	public static final int HUNDRET_DIVISION = 100;
	public static final int TEN_DIVISION = 10;

	public static boolean findPalindrom(int userValue) {

		int valueFirst = userValue / THOUSAND_DIVISION;
		int valueSecond = (userValue - valueFirst * THOUSAND_DIVISION) / HUNDRET_DIVISION;
		int valueThird = (userValue - valueFirst * THOUSAND_DIVISION - valueSecond * HUNDRET_DIVISION) / TEN_DIVISION;
		int valueFourth = userValue - valueFirst * THOUSAND_DIVISION - valueSecond * HUNDRET_DIVISION
				- valueThird * TEN_DIVISION;

		return ((valueFirst == valueFourth) && (valueSecond == valueThird))
				|| ((valueFirst == valueSecond) && (valueSecond == valueThird) && (valueThird == valueFourth));

	}

}
