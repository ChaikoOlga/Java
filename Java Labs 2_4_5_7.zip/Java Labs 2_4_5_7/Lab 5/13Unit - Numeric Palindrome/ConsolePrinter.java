public class ConsolePrinter {
	
	public static void print(String msg) {
		
		System.out.print(msg);
	}

}
