
public class IncreasingSequence {
	
	public static void main(String[] args) {
		
		int userValue = UserInput.input("Enter four digit number: ");
		
		boolean result = BusinessLogic.findPalindrom(userValue);
		
		String msg = (result == true)?"This is a numeric palindrom�":"This is not a numeric palindrom�";
		
		ConsolePrinter.print(msg);
		
	}

}
