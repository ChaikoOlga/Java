public class OnlyOneEvenNumber {
	public static void main(String[] args) {
		
		String msg = "Enter your number: ";
		
		double value1 = UserInput.input(msg);
		double value2 = UserInput.input(msg);
		double value3 = UserInput.input(msg);
		
		boolean result = EvenLogic.findOnlyOneEvenNumber(value1, value2, value3);
		
		ConsolePrinter.print("The statement \"Only one number is even\" is " + result);
	}

}
