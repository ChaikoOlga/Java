
public class EvenLogic {

	public static boolean findOnlyOneEvenNumber(double value1, double value2, double value3) {

		return ((int) value1 % 2 == 0 && (int) value2 % 2 != 0 && (int) value3 % 2 != 0)
				|| ((int) value1 % 2 != 0 && (int) value2 % 2 == 0 && (int) value3 % 2 != 0)
				|| ((int) value1 % 2 != 0 && (int) value2 % 2 != 0 && (int) value3 % 2 == 0);
	}

}
