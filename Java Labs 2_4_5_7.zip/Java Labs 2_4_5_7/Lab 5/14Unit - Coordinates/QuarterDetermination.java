
public class QuarterDetermination {
	public static void main(String[] args) {

		int x = UserInput.input("Enter the abscissa value: ");
		int y = UserInput.input("Enter the ordinate value: ");

		String msg = BusinessLogic.determineCoordQuarter(x, y);

		ConsolePrinter.print("The point is in " + msg);
	}

}
