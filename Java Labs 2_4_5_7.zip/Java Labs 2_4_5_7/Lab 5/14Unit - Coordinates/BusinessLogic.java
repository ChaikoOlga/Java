
public class BusinessLogic {
	public static String determineCoordQuarter(int x, int y) {

		return (x >= 0) ? (y >= 0 ? "1 quarter" : "2 quarter") : (y > 0 ? "4 quarter" : "3 quarter");
	}

}
