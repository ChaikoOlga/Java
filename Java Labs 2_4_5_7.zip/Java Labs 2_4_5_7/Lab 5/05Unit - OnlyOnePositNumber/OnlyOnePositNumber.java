//package lab5U5OnlyOnePositNumber;

public class OnlyOnePositNumber {
	public static void main(String[] args) {

		String msg = "Enter the number please: ";

		double value1 = UserInput.input(msg);
		double value2 = UserInput.input(msg);
		double value3 = UserInput.input(msg);

		boolean result = BusinessLogic.findOnePositiveNumber(value1, value2, value3);

		ConsolePrinter.output("The statement \"Only one numbers is positive\" is " + result);
	}

}
