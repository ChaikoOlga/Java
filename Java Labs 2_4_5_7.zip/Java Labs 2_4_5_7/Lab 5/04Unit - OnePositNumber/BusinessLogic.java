//package lab5U3_PositNumbers;

public class BusinessLogic {

	public static boolean definePositiveNumbers(double value1, double value2, double value3) {
		return value1 > 0 || value2 > 0 || value3 > 0;
	}

}
