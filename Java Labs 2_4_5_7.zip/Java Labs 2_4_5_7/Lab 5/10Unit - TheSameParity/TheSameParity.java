
public class TheSameParity {
	public static void main(String[] args) {

		String msg = "Enter your number: ";

		double value1 = UserInput.input(msg);
		double value2 = UserInput.input(msg);
		double value3 = UserInput.input(msg);

		boolean result = ParityLogic.determineParity(value1, value2, value3);

		ConsolePrinter.print("The statement \"All the numbers have the same parity\" is " + result);
	}

}
