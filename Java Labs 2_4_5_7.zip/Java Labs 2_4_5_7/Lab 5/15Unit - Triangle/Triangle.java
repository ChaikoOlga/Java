

public class Triangle {
	public static void main(String[] args) {

		String msg = "Enter the length of the side";

		int side1 = UserInput.input(msg + " 1:");
		int side2 = UserInput.input(msg + " 2:");
		int side3 = UserInput.input(msg + " 3:");

		boolean res = BusinessLogic.isTriangle(side1, side2, side3);

		ConsolePrinter.print("Result is " + res);

	}

}
