public class EvenNumbers {
	
	public static void main(String[] args) {

		String msg = "Enter the number please: ";

		double value1 = UserInput.input(msg);
		double value2 = UserInput.input(msg);
		double value3 = UserInput.input(msg);

		boolean result = BusinessLogic.findEvenNumbers(value1, value2, value3);

		ConsolePrinter.output("The statement \"All the numbers are even\" is " + result);
	}

}
