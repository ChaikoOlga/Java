//package lab5U20coord;

public class PointCoordinate {
	public static void main(String[] args) {

		int xLeftUp = UserInput.input("Enter the abscissa of the upper left vertex of the rectangle:");
		int yLeftUp = UserInput.input("Enter the ordinate of the upper left vertex of the rectangle:");
		int xRightDown = UserInput.input("Enter the abscissa of the lower right vertex of the rectangle:");
		int yRightDown = UserInput.input("Enter the ordinate of the lower right vertex of the rectangle:");

		int xPoint = UserInput.input("Enter the abscissa of the point");
		int yPoint = UserInput.input("Enter the ordinate of the point");

		boolean res = CootdinateLogice.findPoint(xLeftUp, yLeftUp, xRightDown, yRightDown, xPoint, yPoint);

		ConsolePrinter.print("Tre result is " + res);

	}

}
