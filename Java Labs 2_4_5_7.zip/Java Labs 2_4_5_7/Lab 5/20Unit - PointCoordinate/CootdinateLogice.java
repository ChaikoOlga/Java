//package lab5U20coord;

public class CootdinateLogice {
	public static boolean findPoint(int xLeftUp, int yLeftUp, int xRightDown, int yRightDown, int xPoint, int yPoint) {
		boolean x = xPoint >= xLeftUp && xPoint <= xRightDown;
		boolean y = yPoint >= yRightDown && yPoint <= yLeftUp;

		return x && y;
	}

}
